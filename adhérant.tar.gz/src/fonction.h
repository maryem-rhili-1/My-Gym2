int verification(char log[],char password[], char hello[]);

void affiche();

void ajouter(char log[50],char password[50],int role);

