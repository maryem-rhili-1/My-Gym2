#include <gtk/gtk.h>


void
on_button1_admin_clicked                     (GtkWidget      *objet_graphique,
                                        gpointer         user_data);
void
on_button2_admin_clicked                     (GtkWidget      *objet_graphique,
                                        gpointer         user_data);
void
on_button3_admin_clicked                     (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void    on_button5_admin_clicked                                 (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_button7_admin_clicked                     (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_button8_admin_clicked                     (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_button9_admin_clicked                     (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_button10_admin_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_button14_admin_clicked                    (GtkWidget      *objet_graphique,
 gpointer         user_data);

void
on_button13_admin_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_button16_admin_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_button17_admin_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_button20_admin_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data);


void
on_button18_admin_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data);


void
on_button23_admin_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_button24_admin_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_button26_admin_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_button27_admin_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_button29_admin_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_button28_admin_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_button30_admin_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_button31_admin_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data);
void
on_button32_admin_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_button35_admin_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_button36_admin_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_button37_admin_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_button38_admin_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_button39_admin_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data);



void
on_button40_admin_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_button41_admin_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_button42_admin_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_button43_admin_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data);










































