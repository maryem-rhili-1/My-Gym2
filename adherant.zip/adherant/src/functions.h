#include <gtk/gtk.h>
int verifier (char login[],char pwd[]);
void message_honoraire (char message[]);
void affichage_liste_adh(GtkWidget *liste);
void affichage_liste_alim(GtkWidget *liste);
void affichage_dispo(GtkWidget *liste);