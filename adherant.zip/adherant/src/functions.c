#include <gtk/gtk.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include "functions.h"

int verifier (char login[],char pwd[])
{
	FILE *fic;
	char login_fic[30];
	char pwd_fic[30];
	int role;
	fic=fopen("src/users.txt","r");
	if (fic!=NULL)
	{
		while (fscanf(fic,"%s %s %d",login_fic,pwd_fic,&role)!=EOF)
		{
			if (strcmp(login_fic,login)==0 && strcmp(pwd_fic,pwd)==0)
			{
				return role;
			}
			else if (strcmp(login_fic,login)==0 && strcmp(pwd_fic,pwd)!=0)
			{
				fclose(fic);
				return 9;
			}
		}
		fclose(fic);
		return 0;
	}
	else printf("Erreur d'ouverture du fichier");
}

void message_honoraire (char message[])
{
	FILE *fic;
	char honoraire[6];
	fic=fopen("src/honoraire.txt","r");
	if (fscanf(fic,"%s",honoraire)!=EOF)
	{	
		strcpy(message,"Votre honoraire est de ");
		strcat(message,honoraire);
	}	
	else
		strcpy(message,"Veuillez ajouter un honoraire");
	fclose(fic);
}

void affichage_liste_adh(GtkWidget *liste)
{
	enum
	{
		nom,
    	prenom,
		num_colonne
	};

	FILE *fic=NULL; 
	GtkListStore *liststore;
	GtkCellRenderer *celrender;
	GtkTreeViewColumn *col;
	char fnom[20];
	char fprenom[20];
	liststore=gtk_list_store_new(num_colonne,G_TYPE_STRING,G_TYPE_STRING);
	fic=fopen("src/liste_adh.txt","r");
	if (fic!=NULL)
	{
		while(fscanf(fic,"%s %s\n", fnom, fprenom)!=EOF)
		{
			GtkTreeIter iter;
			gtk_list_store_append(liststore,&iter);
			gtk_list_store_set(liststore,&iter,
					 	nom, fnom,
					    prenom, fprenom,
						-1);
		}
		celrender=gtk_cell_renderer_text_new();
		col= gtk_tree_view_column_new_with_attributes("Nom            ",celrender,"text", nom, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),col);

		celrender=gtk_cell_renderer_text_new();
		col= gtk_tree_view_column_new_with_attributes("Prénom",celrender,"text", prenom, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),col);

		gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(liststore));


	fclose(fic);
 	}

	else printf("impossible d'ouvrire le fichier");
}

void affichage_liste_alim(GtkWidget *liste)
{
	enum
	{
		alim_evit,
    	alim_dav,
    	alim_mod,
    	/*select,*/
		num_colonne
	};

	FILE *fic=NULL; 
	GtkListStore *liststore;
	GtkCellRenderer *celrender;
	GtkTreeViewColumn *col;
	char falim_evit[20];
	char falim_dav[20];
	char falim_mod[20];
	strcpy(falim_evit,"-");
	strcpy(falim_dav,"-");
	strcpy(falim_mod,"-");
	liststore=gtk_list_store_new(num_colonne,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING/*,G_TYPE_BOOLEAN*/);
	fic=fopen("src/liste_alim.txt","r");
	if (fic!=NULL)
	{
		while(fscanf(fic,"%s %s %s\n", falim_dav, falim_evit, falim_mod)!=EOF)
		{
			GtkTreeIter iter;
			gtk_list_store_append(liststore,&iter);
			gtk_list_store_set(liststore,&iter,
					 	alim_evit, falim_evit,
					    alim_dav, falim_dav,
					    alim_mod, falim_mod,
					    /*select, FALSE,*/
						-1);
		}
		//celrender=gtk_cell_renderer_toggle_new();
		//col= gtk_tree_view_column_new_with_attributes("",celrender,"active", select, NULL);
		//gtk_tree_view_append_column(GTK_TREE_VIEW(liste),col);
		//gtk_cell_renderer_toggle_set_activatable(GTK_CELL_RENDERER_TOGGLE(select), 1);

		celrender=gtk_cell_renderer_text_new();
		col= gtk_tree_view_column_new_with_attributes("Aliments à consommer davantage      ",celrender,"text", alim_dav, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),col);

		celrender=gtk_cell_renderer_text_new();
		col= gtk_tree_view_column_new_with_attributes("Aliments à éviter                   ",celrender,"text", alim_evit, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),col);

		celrender=gtk_cell_renderer_text_new();
		col= gtk_tree_view_column_new_with_attributes("Aliments à consommer avec modération",celrender,"text", alim_mod, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),col);

		gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(liststore));


	fclose(fic);
 	}

	else printf("impossible d'ouvrire le fichier");
}

void affichage_dispo(GtkWidget *liste)
{
	enum
	{
		seance,
    	dispo,
    	role,
    	/*select,*/
		num_colonne
	};

	FILE *fic=NULL; 
	GtkListStore *liststore;
	GtkCellRenderer *celrender;
	GtkTreeViewColumn *col;
	char fseance[20];
	char fdispo[20];
	char frole[20];
	liststore=gtk_list_store_new(num_colonne,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING/*,G_TYPE_BOOLEAN*/);
	fic=fopen("src/dispo.txt","r");
	if (fic!=NULL)
	{
		while(fscanf(fic," %s %s %s\n",frole, fseance, fdispo)!=EOF)
		{
			if (strcmp(frole,"Dietheticien")==0)
			{
				GtkTreeIter iter;
				gtk_list_store_append(liststore,&iter);
				gtk_list_store_set(liststore,&iter,
					 	seance, fseance,
					    dispo, fdispo,
					    role, frole,
					    /*select, FALSE,*/
						-1);
			}
		}
		//celrender=gtk_cell_renderer_toggle_new();
		//col= gtk_tree_view_column_new_with_attributes("",celrender,"active", select, NULL);
		//gtk_tree_view_append_column(GTK_TREE_VIEW(liste),col);
		//gtk_cell_renderer_toggle_set_activatable(GTK_CELL_RENDERER_TOGGLE(select), 1);

		celrender=gtk_cell_renderer_text_new();
		col= gtk_tree_view_column_new_with_attributes("Séance",celrender,"text", seance, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),col);

		celrender=gtk_cell_renderer_text_new();
		col= gtk_tree_view_column_new_with_attributes("Disponibilté",celrender,"text", dispo, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),col);

		gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(liststore));


	fclose(fic);
 	}

	else printf("impossible d'ouvrire le fichier");
}
