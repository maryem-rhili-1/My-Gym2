#ifndef reservation_H_INCLUDED	
#define reservation_H_INCLUDED
#include "fonction.h"
#include <gtk/gtk.h>
typedef struct
{
int jour;
int mois;
int annee;
}Date;
typedef struct
{
char hr_seance[50];
char type_seance[50];
Date dt_seance;

}seance;

int verification(char log[],char password[], char hello[]);

void affiche();

///////////////////////////////////////////////////////////


void ajouter(char log[50],char password[50],char role[50]);

void ajoute_evenement_adh(char log[],char event[],char jour[],char mois[],char ans[],char heure[]);

void ajout_seance_adh(char type[] ,char jour[] ,char mois[], char annee[],char heure[] );




////////////////////////////////////////////////////////////



void ajout_participe_event_adh(char event[50],char jour[50],char mois[50],char ans[50],char heure[50]);

void modifier_participe_event_adh(char event[50],char jour[50],char mois[50],char ans[50],char heure[50]);

void supp_participe_event_adh(char event[],char jour[],char mois[],char ans[],char heure[]);

void modifier_comptes_adh(char type[] ,char jour[] ,char mois[], char annee[],char heure[]);

void supprimer_adh(char type[] ,char jour[] ,char mois[], char annee[],char heure[]);


///////////////////////////////////////////////////////

void afficher_event_adh(GtkWidget *pListView);

void afficher_particip_seance_adh(GtkWidget *pListView,char type[]);

void afficher_liste_staff_adh(GtkWidget *pListView,char role[50]);

void afficher_participe_event_adh(GtkWidget *pListView);

//void modifier_profil_adh(char login[] ,char nom[] ,char prenom[], char sexe[],char age[]);

#endif

