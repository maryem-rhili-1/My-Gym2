#include<string.h>
#include <stdio.h>
#include <stdlib.h>
#include "fonction.h"




int verification(char log[],char password[], char hello[])
{
	FILE *f;
	char var[50];char var1[50];int var2;
	f=fopen("/home/karim/Projects/adherant/src/user.txt","r");
	
	
		while(fscanf(f,"%s %s %d",var,var1,&var2)!=EOF)
		{
			if(!strcmp(log,var) && !strcmp(password,var1) )
			{
				strcpy(hello , "yes");
				strcat(hello," ");
				strcat(hello,log);
				fclose(f);
				return var2;
			}

			
		}

				strcpy(hello , "info invalid");
				fclose(f);
				return 0;
		
}








void affiche()
{
	FILE *f;
	char var[50];char var1[50];int var2;
f=fopen("/home/karim/Desktop/atelier-glade/src/user.txt","r");
	
while(fscanf(f,"%s %s %d",var,var1,&var2)!=EOF)
	{

		printf("%s %s %d\n",var,var1,var2);
		
	}
fclose(f);


}






///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////




void ajouter(char log[50],char password[50],char role[50])
{
FILE *f;

f=fopen("/home/karim/Projects/adherant/src/user1.txt","a+");

		
	
	
	fprintf(f,"%s %s %s\n",log,password,role);
	
fclose(f);
}





////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////







void ajoute_evenement_adh(char log[],char event[],char jour[],char mois[],char ans[],char heure[])
{
FILE *f;

f=fopen("/home/karim/Projects/adherant/src/participant_evenement.txt","a+");

	fprintf(f,"%s %s %s %s %s \n",log,event,jour,mois,ans);
	
fclose(f);
}



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////







void ajout_seance_adh(char type[] ,char jour[] ,char mois[], char annee[],char heure[] )
{
FILE *f;

f=fopen("/home/karim/Projects/adherant/src/rendezvous.txt","a+");

		
	
	
	fprintf(f,"%s %s %s %s %s \n",type,jour,mois,annee,heure);
	
fclose(f);
}




////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////                                                                     ////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////





void afficher_event_adh(GtkWidget *pListView)
{

enum {
EVENT,
JOUR,
MOIS,
ANNEE,
HEURE,
TOGGLE_COLUMN,
N_COLUMN
};

GtkWidget *pScrollbar;
GtkListStore *pListStore;
GtkTreeViewColumn *pColumn;
GtkCellRenderer *pCellRenderer;
pListStore = gtk_tree_view_get_model(GTK_TREE_VIEW(pListView));

FILE *f;char var[50],var1[50],var3[50], var2[50],var4[50];
f=fopen("/home/karim/Projects/adherant/src/evenement.txt","r");

if (pListStore == NULL) {



pCellRenderer = gtk_cell_renderer_text_new();
pColumn = gtk_tree_view_column_new_with_attributes("event",
pCellRenderer,
"text", EVENT,
NULL);

gtk_tree_view_append_column(GTK_TREE_VIEW(pListView), pColumn);

pCellRenderer = gtk_cell_renderer_text_new();
pColumn = gtk_tree_view_column_new_with_attributes("jour",
pCellRenderer,
"text", JOUR,
NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(pListView), pColumn);

pCellRenderer = gtk_cell_renderer_text_new();
pColumn = gtk_tree_view_column_new_with_attributes("mois",pCellRenderer,"text", MOIS,NULL);

gtk_tree_view_append_column(GTK_TREE_VIEW(pListView), pColumn);

pCellRenderer = gtk_cell_renderer_text_new();
pColumn = gtk_tree_view_column_new_with_attributes("année",pCellRenderer,"text", ANNEE,NULL);

gtk_tree_view_append_column(GTK_TREE_VIEW(pListView), pColumn);

pCellRenderer = gtk_cell_renderer_text_new();
pColumn = gtk_tree_view_column_new_with_attributes("heure",
pCellRenderer,
"text", HEURE,
NULL);

gtk_tree_view_append_column(GTK_TREE_VIEW(pListView), pColumn);



pCellRenderer = gtk_cell_renderer_toggle_new();
pColumn=gtk_tree_view_column_new_with_attributes("select",pCellRenderer,"false", TOGGLE_COLUMN,
NULL);


}


pListStore = gtk_list_store_new(N_COLUMN, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING,G_TYPE_BOOLEAN);


while(fscanf(f,"%s %s %s %s %s",var,var1,var2,var3,var4)!=EOF)
	{



GtkTreeIter pIter;

gtk_list_store_append(pListStore, &pIter);
gtk_list_store_set(pListStore, &pIter,EVENT,var,JOUR,var1,MOIS,var2,ANNEE,var3,HEURE,var4,TOGGLE_COLUMN,-1);
	}



fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(pListView),GTK_TREE_MODEL(pListStore)); 
g_object_unref(pListStore);	
}






/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


void afficher_participe_event_adh(GtkWidget *pListView)
{

enum {
EVENT,
JOUR,
MOIS,
ANNEE,
HEURE,
TOGGLE_COLUMN,
N_COLUMN
};

GtkWidget *pScrollbar;
GtkListStore *pListStore;
GtkTreeViewColumn *pColumn;
GtkCellRenderer *pCellRenderer;
pListStore = gtk_tree_view_get_model(GTK_TREE_VIEW(pListView));

FILE *f;char var[50],var1[50],var3[50], var2[50],var4[50];
f=fopen("/home/karim/Projects/adherant/src/participant_evenement.txt","r");

if (pListStore == NULL) {



pCellRenderer = gtk_cell_renderer_text_new();
pColumn = gtk_tree_view_column_new_with_attributes("event",
pCellRenderer,
"text", EVENT,
NULL);

gtk_tree_view_append_column(GTK_TREE_VIEW(pListView), pColumn);

pCellRenderer = gtk_cell_renderer_text_new();
pColumn = gtk_tree_view_column_new_with_attributes("jour",
pCellRenderer,
"text", JOUR,
NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(pListView), pColumn);

pCellRenderer = gtk_cell_renderer_text_new();
pColumn = gtk_tree_view_column_new_with_attributes("mois",pCellRenderer,"text", MOIS,NULL);

gtk_tree_view_append_column(GTK_TREE_VIEW(pListView), pColumn);

pCellRenderer = gtk_cell_renderer_text_new();
pColumn = gtk_tree_view_column_new_with_attributes("année",pCellRenderer,"text", ANNEE,NULL);

gtk_tree_view_append_column(GTK_TREE_VIEW(pListView), pColumn);

pCellRenderer = gtk_cell_renderer_text_new();
pColumn = gtk_tree_view_column_new_with_attributes("heure",
pCellRenderer,
"text", HEURE,
NULL);

gtk_tree_view_append_column(GTK_TREE_VIEW(pListView), pColumn);



pCellRenderer = gtk_cell_renderer_toggle_new();
pColumn=gtk_tree_view_column_new_with_attributes("select",pCellRenderer,"false", TOGGLE_COLUMN,
NULL);


}


pListStore = gtk_list_store_new(N_COLUMN, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING,G_TYPE_BOOLEAN);


while(fscanf(f,"%s %s %s %s %s",var,var1,var2,var3,var4)!=EOF)
	{



GtkTreeIter pIter;

gtk_list_store_append(pListStore, &pIter);
gtk_list_store_set(pListStore, &pIter,EVENT,var,JOUR,var1,MOIS,var2,ANNEE,var3,HEURE,var4,TOGGLE_COLUMN,-1);
	}



fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(pListView),GTK_TREE_MODEL(pListStore)); 
g_object_unref(pListStore);	
}












///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////                                                                                                       ///////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////





void afficher_liste_staff_adh(GtkWidget *pListView,char role1[50])
{

enum {
ROLE,
HEURE,
DISPO,
TOGGLE_COLUMN,
N_COLUMN
};

void toggled_func(GtkCellRendererToggle *cell_renderer, gchar *path, gpointer user_data)
{
 
    GtkTreeIter iter;
    GtkTreePath *ppath;
    gboolean boolean;
 
 
// convertir la chaine path en GtkTreePath 
 
     ppath = gtk_tree_path_new_from_string (path);
 
// convertir la valeure recuperée en GtkTreeIter  
     gtk_tree_model_get_iter (GTK_TREE_MODEL (user_data),
                           &iter,
                           ppath);
//  utiliser la variable GtkTreeIter pour acceder la valeure booleaine                           
     gtk_tree_model_get (GTK_TREE_MODEL (user_data),
                           &iter,
                           TOGGLE_COLUMN,&boolean,
                           -1);
// changer cette valeure booleaine (! boolean )                          
     gtk_list_store_set (user_data, &iter,
                      TOGGLE_COLUMN, !boolean,
                      -1);
 
 
}


GtkWidget *pScrollbar;
GtkListStore *pListStore;
GtkTreeViewColumn *pColumn;
GtkCellRenderer *pCellRenderer;
pListStore = gtk_tree_view_get_model(pListView);

FILE *f;char var[50],var1[50];char var2[50];
f=fopen("src/disponibilite.txt","r");

if (pListStore == NULL) {



pCellRenderer = gtk_cell_renderer_text_new();
pColumn = gtk_tree_view_column_new_with_attributes("role",
pCellRenderer,
"text", ROLE,
NULL);

gtk_tree_view_append_column(GTK_TREE_VIEW(pListView), pColumn);

pCellRenderer = gtk_cell_renderer_text_new();
pColumn = gtk_tree_view_column_new_with_attributes("heure",
pCellRenderer,
"text", HEURE,
NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(pListView), pColumn);

pCellRenderer = gtk_cell_renderer_text_new();
pColumn = gtk_tree_view_column_new_with_attributes("disonibilité",
pCellRenderer,
"text", DISPO,
NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(pListView), pColumn);


pCellRenderer = gtk_cell_renderer_toggle_new();
pColumn=gtk_tree_view_column_new_with_attributes("select",pCellRenderer,"active", TOGGLE_COLUMN,
NULL);

g_signal_connect(G_OBJECT(pCellRenderer), "toggled", (GCallback)toggled_func, pListStore);
gtk_tree_view_append_column(GTK_TREE_VIEW(pListView), pColumn);	



}

pListStore = gtk_list_store_new(N_COLUMN, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,G_TYPE_BOOLEAN);


while(fscanf(f,"%s %s %s",var,var1,var2)!=EOF)
	{

if (strcmp(var,role1)!=0)
continue;

GtkTreeIter pIter;

gtk_list_store_append(pListStore, &pIter);
gtk_list_store_set(pListStore, &pIter,ROLE,var,HEURE,var1,DISPO,var2,TOGGLE_COLUMN,FALSE,-1);

}

																																												
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(pListView),GTK_TREE_MODEL(pListStore)); 
g_object_unref(pListStore);	

	}



//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////                                                                                                                //////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


void afficher_particip_seance_adh(GtkWidget *pListView,char type[])
{ 

enum {
TYPE,
JOUR,
MOIS,
ANNEE,
HEURE,
TOGGLE_COLUMN,
N_COLUMN
};


void toggled_func(GtkCellRendererToggle *cell_renderer, gchar *path, gpointer user_data)
{
 
    GtkTreeIter iter;
    GtkTreePath *ppath;
    gboolean boolean;
 
 
// convertir la chaine path en GtkTreePath 
 
     ppath = gtk_tree_path_new_from_string (path);
 
// convertir la valeure recuperée en GtkTreeIter  
     gtk_tree_model_get_iter (GTK_TREE_MODEL (user_data),
                           &iter,
                           ppath);
//  utiliser la variable GtkTreeIter pour acceder la valeure booleaine                           
     gtk_tree_model_get (GTK_TREE_MODEL (user_data),
                           &iter,
                           TOGGLE_COLUMN,&boolean,
                           -1);
// changer cette valeure booleaine (! boolean )                          
     gtk_list_store_set (user_data, &iter,
                      TOGGLE_COLUMN, !boolean,
                      -1);
 
 
}

GtkWidget *pScrollbar;
GtkListStore *pListStore;
GtkTreeViewColumn *pColumn;
GtkCellRenderer *pCellRenderer;
pListStore = gtk_tree_view_get_model(pListView);

FILE *f;char var[50],var1[50],var2[50],var3[50],var4[50];
f=fopen("/home/karim/Projects/adherant/src/rendezvous.txt","r");

if (pListStore == NULL) {



pCellRenderer = gtk_cell_renderer_text_new();
pColumn = gtk_tree_view_column_new_with_attributes("type",
pCellRenderer,
"text", TYPE,
NULL);

gtk_tree_view_append_column(GTK_TREE_VIEW(pListView), pColumn);

pCellRenderer = gtk_cell_renderer_text_new();
pColumn = gtk_tree_view_column_new_with_attributes("jour",
pCellRenderer,
"text", JOUR,
NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(pListView), pColumn);

pCellRenderer = gtk_cell_renderer_text_new();
pColumn = gtk_tree_view_column_new_with_attributes("mois",
pCellRenderer,
"text", MOIS,
NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(pListView), pColumn);


pCellRenderer = gtk_cell_renderer_text_new();
pColumn = gtk_tree_view_column_new_with_attributes("année",
pCellRenderer,
"text", ANNEE,
NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(pListView), pColumn);

pCellRenderer = gtk_cell_renderer_text_new();
pColumn = gtk_tree_view_column_new_with_attributes("heure",
pCellRenderer,
"text", HEURE,
NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(pListView), pColumn);

	
pCellRenderer = gtk_cell_renderer_toggle_new();
pColumn=gtk_tree_view_column_new_with_attributes("select",pCellRenderer,"active", TOGGLE_COLUMN,
NULL);

g_signal_connect(G_OBJECT(pCellRenderer), "toggled", (GCallback)toggled_func, pListStore);
gtk_tree_view_append_column(GTK_TREE_VIEW(pListView), pColumn);	



}

pListStore = gtk_list_store_new(N_COLUMN, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING, G_TYPE_STRING, G_TYPE_BOOLEAN);


while(fscanf(f,"%s %s %s %s %s",var,var1,var2,var3,var4)!=EOF)
	{

if (strcmp(type,var)==0)
continue;

GtkTreeIter pIter;

gtk_list_store_append(pListStore, &pIter);
gtk_list_store_set(pListStore, &pIter,TYPE,var,JOUR,var1,MOIS,var2,ANNEE,var3,HEURE,var4,TOGGLE_COLUMN,FALSE,-1);

}


fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(pListView),GTK_TREE_MODEL(pListStore)); 
g_object_unref(pListStore);	

	}







//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////                                                                                                       /////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////





void ajout_participe_event_adh(char event[50],char jour[50],char mois[50],char ans[50],char heure[50])
{
FILE *f;

f=fopen("/home/karim/Projects/adherant/src/participant_evenement.txt","a+");

		
	
	
	fprintf(f,"%s %s %s %s %s \n",event,jour,mois,ans,heure);
	
fclose(f);
}


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////





void modifier_participe_event_adh(char event[50],char jour[50],char mois[50],char ans[50],char heure[50])
{
FILE *f,*f1;
char var[50];char var1[50];char var2[50];char var3[50];char var4[50];
f=fopen("/home/karim/Projects/adherant/src/participant_evenement.txt","r");
f1=fopen("/home/karim/Projects/adherant/src/tompo.txt","w+");
while(fscanf(f,"%s %s %s %s %s",var,var1,var2,var3,var4)!=EOF)
	{
if (strcmp(event,var)==0 )
		{
fprintf(f1,"%s %s %s %s %s \n",var,jour,mois,ans,heure);

	
		}
else
fprintf(f1,"%s %s %s %s %s \n",var,var1,var2,var3,var4);
	}
fclose(f1);
fclose(f);
rename("/home/karim/Projects/adherant/src/tompo.txt","/home/karim/Projects/adherant/src/participant_evenement.txt");	
}




///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////





void supp_participe_event_adh(char event[],char jour[],char mois[],char ans[],char heure[])
{
FILE *f,*f1;
char var[50];char var1[50];char var2[50];char var3[50];char var4[50];
f=fopen("/home/karim/Projects/adherant/src/participant_evenement.txt","r");
f1=fopen("/home/karim/Projects/adherant/src/tompo.txt","w+");
while(fscanf(f,"%s %s %s %s %s",var,var1,var2,var3,var4)!=EOF)
	{
if (strcmp(var,event)==0 ){continue;}
		
else
fprintf(f1,"%s %s %s %s %s\n",var,var1,var2,var3,var4);
	}
fclose(f1);
fclose(f);
rename("/home/karim/Projects/adherant/src/tompo.txt","/home/karim/Projects/adherant/src/participant_evenement.txt");	
}





/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////                                                                                                            ///////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////





void modifier_comptes_adh(char type[] ,char jour[] ,char mois[], char annee[],char heure[])
{
FILE *f,*f1;
char var[50];char var1[50];char var2[50];char var3[50];char var4[50];
f=fopen("/home/karim/Projects/adherant/src/rendezvous.txt","r");
f1=fopen("/home/karim/Projects/adherant/src/tampon.txt","w+");
while(fscanf(f,"%s %s %s %s %s",var,var1,var2,var3,var4)!=EOF)
	{
if (strcmp(var4,heure)==0)
		{
fprintf(f1,"%s %s %s %s %s \n",type,jour,mois,annee,var4);

	
		}
else
fprintf(f1,"%s %s %s %s %s \n",var,var1,var2,var3,var4);
	}
fclose(f1);
fclose(f);
rename("/home/karim/Projects/adherant/src/tampon.txt","/home/karim/Projects/adherant/src/rendezvous.txt");	
}



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////                                                                                                  /////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



void supprimer_adh(char type[] ,char jour[] ,char mois[], char annee[],char heure[])
{ 	
	FILE *f,*f1;
char var[50];char var1[50];char var2[50];char var3[50];char var4[50];
f=fopen("/home/karim/Projects/adherant/src/rendezvous.txt","r");
f1=fopen("/home/karim/Projects/adherant/src/tampon.txt","w+");
	while(fscanf(f,"%s %s %s %s %s",var,var1,var2,var3,var4)!=EOF){
		if(strcmp(var4,heure)==0){continue;}
else fprintf(f1,"%s %s %s %s %s \n",var,var1,var2,var3,var4);
}
fclose(f);
fclose(f1);
rename("/home/karim/Projects/adherant/src/tampon.txt","/home/karim/Projects/adherant/src/rendezvous.txt");
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////                                                                                        //////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



/*void modifier_profil(char login[] ,char nom[] ,char prenom[], char sexe[],char age[])
{
FILE *f,*f1;
char var[50];char var1[50];char var2[50];char var3[50];char var4[50];
f=fopen("/home/karim/Projects/adherant/src/profil.txt","r");
f1=fopen("/home/karim/Projects/adherant/src/tampon.txt","w+");
while(fscanf(f,"%s %s %s %s %s",var,var1,var2,var3,var4)!=EOF)
	{
if (strcmp(var1,login)==0)
		{
fprintf(f1,"%s %s %s %s %s \n",var1,nom,prenom,sexe,age);

	
		}
else
fprintf(f1,"%s %s %s %s %s \n",var,var1,var2,var3,var4);
	}
fclose(f1);
fclose(f);
rename("/home/karim/Projects/adherant/src/tampon.txt","/home/karim/Projects/adherant/src/rendezvous.txt");	
}*/





/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////                                                                                             /////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////















































