#include <gtk/gtk.h>




void afficher1_kine(GtkWidget *fifistview);

void ajouter_dispo_kine(int jour,int mois,int annee,char Heurs[50]);

void supprimer_dispo_kine(int jour,int mois,int annee,char Heurs[50], char Heurs1[50]);

void afficher2_kine(GtkWidget *filistview);
