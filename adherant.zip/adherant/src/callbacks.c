#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <string.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fonction.h"
#include "functions.h"
#include "kine.h"



void on_button1_clicked (GtkWidget *widget, gpointer user_data)
{
	GtkWidget *entry1;
	GtkWidget *entry2;
	GtkWidget *label4;
	GtkWidget *label5;
	GtkWidget *window1;
	GtkWidget *window2;
	GtkWidget *window_menu_adherant;
	GtkWidget *window_menu_kine;
	char login[20];
	char pwd[20];
	int ver;

	window1=lookup_widget(widget,"window1");
	label4=lookup_widget(widget,"label4");
	label5=lookup_widget(widget,"label5");
	entry1=lookup_widget(widget,"entry1");
	entry2=lookup_widget(widget,"entry2");
	strcpy(login,gtk_entry_get_text(GTK_ENTRY(entry1)));
	strcpy(pwd,gtk_entry_get_text(GTK_ENTRY(entry2)));
	ver=verifier(login,pwd);
	if (ver==2)
	{
		window_menu_adherant = create_window_menu_adherant ();
		gtk_widget_hide(GTK_WIDGET(window1));
		gtk_widget_show(GTK_WIDGET(window_menu_adherant));
	}
	else if (ver==5)
	{
		window2 = create_window2 ();
		gtk_widget_hide(GTK_WIDGET(window1));
		gtk_widget_show(GTK_WIDGET(window2));
	}
	else if (ver==6)
	{
		window_menu_kine = create_window_menu_kine ();
		gtk_widget_hide(GTK_WIDGET(window1));
		gtk_widget_show(GTK_WIDGET(window_menu_kine));
	}
	else if (ver==9)
	{
		gtk_widget_hide(GTK_WIDGET(label4));
		gtk_widget_show(GTK_WIDGET(label5));
	}
	else
	{
		gtk_widget_show(GTK_WIDGET(label5));
		gtk_widget_show(GTK_WIDGET(label4));
	}
	printf("%d",ver);
	
}


void on_button2_clicked (GtkWidget *widget, gpointer user_data)
{
	GtkWidget *window1;
	GtkWidget *window2;

	window2=lookup_widget(widget,"window2");
	window1 = create_window1 ();
	gtk_widget_hide(GTK_WIDGET(window2));
	gtk_widget_show(GTK_WIDGET(window1));
}


void on_button3_clicked (GtkWidget *widget, gpointer user_data)
{
	GtkWidget *window8;
	GtkWidget *window3;
	GtkWidget *liste;
	
	window8 = create_window8 ();
	liste=lookup_widget(window8,"treeview1");
	affichage_liste_adh(liste);
	gtk_widget_show(GTK_WIDGET(window8));
	
}


void on_button4_clicked (GtkWidget *widget, gpointer user_data)
{
	GtkWidget *window9;
	GtkWidget *window3;
	GtkWidget *liste;
	
	window9 = create_window9 ();
	liste=lookup_widget(window9,"treeview2");
	affichage_liste_adh(liste);
	gtk_widget_show(GTK_WIDGET(window9));
}


void on_button5_clicked (GtkWidget *widget, gpointer user_data)
{
	GtkWidget *window6;
	GtkWidget *window2;
	GtkWidget *entry5;
	GtkWidget *entry6;
	GtkWidget *entry7;
	GtkWidget *entry8;
	FILE *fic;
	char nom[20];
	char prenom[20];
	char age[6];
	char sexe[6];

	window2=lookup_widget(widget,"window2");
	window6 = create_window6 ();
	entry5=lookup_widget(window6,"entry5");
	entry6=lookup_widget(window6,"entry6");
	entry7=lookup_widget(window6,"entry7");
	entry8=lookup_widget(window6,"entry8");
	strcpy(nom,"");
	strcpy(prenom,"");
	strcpy(age,"");
	strcpy(sexe,"");
	fic=fopen("src/info_profil.txt","r");
	if (fic!=NULL)
	{
		while (fscanf(fic,"%s %s %s %s\n",nom,prenom,age,sexe)!=EOF)
		{
			break;
		}
		fclose(fic);
	}
	else printf("Erreur d'ouverture du fichier");
	gtk_entry_set_text(GTK_ENTRY(entry5),nom);
	gtk_entry_set_text(GTK_ENTRY(entry6),prenom);
	gtk_entry_set_text(GTK_ENTRY(entry8),age);
	gtk_entry_set_text(GTK_ENTRY(entry7),sexe);
	gtk_widget_hide(GTK_WIDGET(window2));
	gtk_widget_show(GTK_WIDGET(window6));
}


void on_button6_clicked (GtkWidget *widget, gpointer user_data)
{
	GtkWidget *window12;
	GtkWidget *window2;
	GtkWidget *liste;

	window2=lookup_widget(widget,"window2");
	window12 = create_window12 ();
	liste=lookup_widget(window12,"treeview5");
	affichage_dispo(liste);
	gtk_widget_show(GTK_WIDGET(window12));
}


void on_button7_clicked (GtkWidget *widget, gpointer user_data)
{
	GtkWidget *window3;
	GtkWidget *window2;

	window2=lookup_widget(widget,"window2");
	window3 = create_window3 ();
	gtk_widget_hide(GTK_WIDGET(window2));
	gtk_widget_show(GTK_WIDGET(window3));
}


void on_button8_clicked (GtkWidget *widget, gpointer user_data)
{
	GtkWidget *window3;
	GtkWidget *window4;

	window3=lookup_widget(widget,"window3");
	window4 = create_window4 ();
	gtk_widget_hide(GTK_WIDGET(window3));
	gtk_widget_show(GTK_WIDGET(window4));
}


void on_button10_clicked (GtkWidget *widget, gpointer user_data)
{
	GtkWidget *entry3;
	GtkWidget *window3;
	GtkWidget *window4;
	FILE *fic;
	char honoraire[5];

	entry3=lookup_widget(widget,"entry3");
	window4=lookup_widget(widget,"window4");
	strcpy(honoraire,gtk_entry_get_text(GTK_ENTRY(entry3)));
	fic=fopen("src/honoraire.txt","a+");
	fprintf(fic,"%sDT\n",honoraire);
	fclose(fic);
	window3 = create_window3 ();
	gtk_widget_show(GTK_WIDGET(window3));
	gtk_widget_hide(GTK_WIDGET(window4));
	
}


void on_button9_clicked (GtkWidget *widget, gpointer user_data)
{
	GtkWidget *window3;
	GtkWidget *window5;

	window3=lookup_widget(widget,"window3");
	window5 = create_window5 ();
	gtk_widget_hide(GTK_WIDGET(window3));
	gtk_widget_show(GTK_WIDGET(window5));
}


void on_button11_clicked (GtkWidget *widget, gpointer user_data)
{
	GtkWidget *entry4;
	GtkWidget *window3;
	GtkWidget *window5;
	FILE *fic;
	char honoraire[5];

	entry4=lookup_widget(widget,"entry4");
	window5=lookup_widget(widget,"window5");
	strcpy(honoraire,gtk_entry_get_text(GTK_ENTRY(entry4)));
	fic=fopen("src/honoraire.txt","w");
	fprintf(fic,"%sDT\n",honoraire);
	fclose(fic);
	window3 = create_window3 ();
	gtk_widget_show(GTK_WIDGET(window3));
	gtk_widget_hide(GTK_WIDGET(window5));
}


void on_button13_clicked (GtkWidget *widget, gpointer user_data)
{
	GtkWidget *window6;
	GtkWidget *window7;

	window6=lookup_widget(widget,"window6");
	window7 = create_window7 ();
	gtk_widget_hide(GTK_WIDGET(window6));
	gtk_widget_show(GTK_WIDGET(window7));
}


void on_button14_clicked (GtkWidget *widget, gpointer user_data)
{
	GtkWidget *window6;
	GtkWidget *window7;
	GtkWidget *entry9;
	GtkWidget *entry10;
	GtkWidget *comboboxentry1;
	GtkWidget *spinbutton1;
	GtkWidget *entry5;
	GtkWidget *entry6;
	GtkWidget *entry7;
	GtkWidget *entry8;
	FILE *fic;
	char nom[20];
	char prenom[20];
	int age;
	char age_char[5];
	char sexe[6];

	entry9=lookup_widget(widget,"entry9");
	entry10=lookup_widget(widget,"entry10");
	window7=lookup_widget(widget,"window7");
	window6 = create_window6 ();
	entry5=lookup_widget(window6,"entry5");
	entry6=lookup_widget(window6,"entry6");
	entry7=lookup_widget(window6,"entry7");
	entry8=lookup_widget(window6,"entry8");
	comboboxentry1=lookup_widget(widget,"comboboxentry1");
	spinbutton1=lookup_widget(widget,"spinbutton1");
	strcpy(nom,gtk_entry_get_text(GTK_ENTRY(entry9)));
	strcpy(prenom,gtk_entry_get_text(GTK_ENTRY(entry10)));
	strcpy(sexe,gtk_combo_box_get_active_text(GTK_COMBO_BOX(comboboxentry1)));
	age=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(spinbutton1));
	fic=fopen("src/info_profil.txt","w");
	fprintf(fic,"%s %s %d %s\n",nom,prenom,age,sexe);
	fclose(fic);
	strcpy(nom,"");
	strcpy(prenom,"");
	strcpy(age_char,"");
	strcpy(sexe,"");
	fic=fopen("src/info_profil.txt","r");
	if (fic!=NULL)
	{
		while (fscanf(fic,"%s %s %s %s\n",nom,prenom,age_char,sexe)!=EOF)
		{
			break;
		}
		fclose(fic);
	}
	else printf("Erreur d'ouverture du fichier");
	gtk_entry_set_text(GTK_ENTRY(entry5),nom);
	gtk_entry_set_text(GTK_ENTRY(entry6),prenom);
	gtk_entry_set_text(GTK_ENTRY(entry8),age_char);
	gtk_entry_set_text(GTK_ENTRY(entry7),sexe);
	gtk_widget_hide(GTK_WIDGET(window7));
	gtk_widget_show(GTK_WIDGET(window6));
}


void on_button15_clicked (GtkWidget *widget, gpointer user_data)
{
	GtkWidget *window2;
	GtkWidget *window3;

	window3=lookup_widget(widget,"window3");
	window2 = create_window2 ();
	gtk_widget_hide(GTK_WIDGET(window3));
	gtk_widget_show(GTK_WIDGET(window2));
}


void on_button16_clicked (GtkWidget *widget, gpointer user_data)
{
	GtkWidget *window4;
	GtkWidget *window3;

	window4=lookup_widget(widget,"window4");
	window3 = create_window3 ();
	gtk_widget_hide(GTK_WIDGET(window4));
	gtk_widget_show(GTK_WIDGET(window3));
}


void on_button17_clicked (GtkWidget *widget, gpointer user_data)
{
	GtkWidget *window5;
	GtkWidget *window3;

	window5=lookup_widget(widget,"window5");
	window3 = create_window3 ();
	gtk_widget_hide(GTK_WIDGET(window5));
	gtk_widget_show(GTK_WIDGET(window3));
}


void on_button18_clicked (GtkWidget *widget, gpointer user_data)
{
	GtkWidget *window6;
	GtkWidget *window2;

	window6=lookup_widget(widget,"window6");
	window2 = create_window2 ();
	gtk_widget_hide(GTK_WIDGET(window6));
	gtk_widget_show(GTK_WIDGET(window2));
}


void on_button19_clicked (GtkWidget *widget, gpointer user_data)
{
	GtkWidget *window7;
	GtkWidget *window6;

	window7=lookup_widget(widget,"window7");
	window6 = create_window6 ();
	gtk_widget_hide(GTK_WIDGET(window7));
	gtk_widget_show(GTK_WIDGET(window6));
}


void on_treeview1_row_activated (GtkWidget *widget, GtkTreePath *path, GtkTreeViewColumn *column, gpointer user_data)
{
	GtkWidget *window16;
	GtkWidget *window2;
	GtkWidget *entry17;
	GtkWidget *entry18;
	GtkWidget *entry19;
	GtkWidget *entry20;
	GtkWidget *entry21;
	GtkWidget *entry22;
	GtkWidget *list_view;
	GtkTreeIter iter;
	gchar *nom;
	gchar *prenom;
	char age[5];
	char taille[20];
	char mal[100];
	char poids[20];
	FILE *fic;

	window16=create_window16();
	entry17=lookup_widget(window16,"entry17");
	entry19=lookup_widget(window16,"entry19");
	entry20=lookup_widget(window16,"entry20");
	entry21=lookup_widget(window16,"entry21");
	entry22=lookup_widget(window16,"entry22");
	list_view=lookup_widget(widget,"treeview1");
	GtkTreeModel *model = gtk_tree_view_get_model (GTK_TREE_VIEW(lookup_widget(widget,"treeview1")));
 	if (gtk_tree_model_get_iter(model, &iter, path))
    	gtk_tree_model_get (GTK_TREE_MODEL(model), &iter, 0, &nom, 1, &prenom, -1);
    gtk_entry_set_text(GTK_ENTRY(entry17),nom);
	gtk_entry_set_text(GTK_ENTRY(entry18),prenom);
	fic=fopen("src/fiche_med.txt","r");
	while (fscanf(fic,"%s %s %s %s\n", age,poids,taille,mal)!=EOF)
		break;
	fclose(fic);
	gtk_entry_set_text(GTK_ENTRY(entry19),age);
	gtk_entry_set_text(GTK_ENTRY(entry20),poids);
	gtk_entry_set_text(GTK_ENTRY(entry21),taille);
	gtk_entry_set_text(GTK_ENTRY(entry22),mal);
	gtk_widget_show(window16);
}


void on_treeview2_row_activated (GtkWidget *widget, GtkTreePath *path, GtkTreeViewColumn *column, gpointer user_data)
{
	GtkWidget *window10;
	GtkWidget *window9;
	GtkWidget *liste;
	
	window10 = create_window10 ();
	window9=lookup_widget(widget,"window9");
	liste=lookup_widget(window10,"treeview3");
	affichage_liste_alim(liste);
	gtk_widget_show(GTK_WIDGET(window10));
	gtk_widget_hide(window9);
	/*gchar nom[20];
	gchar prenom[20];
	GtkTreeIter iter;
	GtkTreeModel *model= gtk_tree_view_get_model(GTK_TREE_VIEW(widget));
	if (gtk_tree_model_get_iter(GTK_TREE_MODEL(model),&iter,path))
		gtk_tree_model_get(GTK_TREE_MODEL(model), 0, nom, 1, prenom, -1);
	printf("%s\n%s\n",nom,prenom);*/
}
void on_button20_clicked (GtkWidget *widget, gpointer user_data)
{
	GtkWidget *window11;
	GtkWidget *window10;
	
	window10=lookup_widget(widget,"window10");
	window11 = create_window11 ();
	gtk_widget_hide(GTK_WIDGET(window10));
	gtk_widget_show(GTK_WIDGET(window11));
}


void on_button21_clicked (GtkWidget *widget, gpointer user_data)
{
	GtkWidget *entry15;
	GtkWidget *liste;
	char alim[20];
	char chtmp1[20];
	char chtmp2[20];
	char chtmp3[20];
	FILE *fic;
	FILE *tmp;

	entry15=lookup_widget(widget,"entry15");
	liste=lookup_widget(widget,"treeview3");
	strcpy(alim,gtk_entry_get_text(GTK_ENTRY(entry15)));
	fic=fopen("src/liste_alim.txt","r");
	tmp=fopen("src/liste_alim1.txt","w+");
	while (fscanf(fic,"%s %s %s\n", chtmp1, chtmp2,chtmp3)!=EOF)
	{
		if (strcmp(chtmp1,"-")!=0 || strcmp(chtmp2,"-")!=0 || strcmp(chtmp3,"-")!=0)
		{
			if (strcmp(chtmp1,alim)==0)
				fprintf(tmp,"%s %s %s\n","-",chtmp2,chtmp3);
			else
				fprintf(tmp,"%s %s %s\n",chtmp1,chtmp2,chtmp3);
		}
	}
	fclose(fic);
	fclose(tmp);
	rename("src/liste_alim1.txt","src/liste_alim.txt");
	affichage_liste_alim(liste);

}



void on_button22_clicked (GtkWidget *widget, gpointer user_data)
{
	GtkWidget *window10;
	GtkWidget *window11;
	GtkWidget *liste;
	GtkWidget *entry11;
	GtkWidget *entry12;
	GtkWidget *entry13;
	char falim_evit[20];
	char falim_dav[20];
	char falim_mod[20];
	int n11,n12,n13;
	FILE *fic=NULL;

	strcpy(falim_dav,"-");
	strcpy(falim_evit,"-");
	strcpy(falim_mod,"-");
	entry13=lookup_widget(widget,"entry13");
	entry12=lookup_widget(widget,"entry12");
	entry11=lookup_widget(widget,"entry11");
	n11=gtk_entry_get_text_length (GTK_ENTRY(entry11));
	n12=gtk_entry_get_text_length (GTK_ENTRY(entry12));
	n13=gtk_entry_get_text_length (GTK_ENTRY(entry13));
	if (n11>0)
		strcpy(falim_dav,gtk_entry_get_text(GTK_ENTRY(entry11)));
	if (n12>0)
		strcpy(falim_evit,gtk_entry_get_text(GTK_ENTRY(entry12)));
	if (n13>0)
		strcpy(falim_mod,gtk_entry_get_text(GTK_ENTRY(entry13)));
	fic=fopen("src/liste_alim.txt","a+");
	if (fic!=NULL)
	{
		fprintf(fic,"%s %s %s\n",falim_dav,falim_evit,falim_mod);
	}
	else
		printf("Erreur !");
	fclose(fic);
	window11=lookup_widget(widget,"window11");
	window10 = create_window10 ();
	liste=lookup_widget(window10,"treeview3");
	affichage_liste_alim(liste);
	gtk_widget_hide(GTK_WIDGET(window11));
	gtk_widget_show(GTK_WIDGET(window10));
}


void on_button24_clicked (GtkWidget *widget, gpointer user_data)
{
	GtkWidget *window12;
	GtkWidget *window15;
	
	window12=lookup_widget(widget,"window12");
	window15 = create_window15 ();
	gtk_widget_hide(GTK_WIDGET(window12));
	gtk_widget_show(GTK_WIDGET(window15));
}


void on_button25_clicked (GtkWidget *widget, gpointer user_data)
{

}


void on_button26_clicked (GtkWidget *widget, gpointer user_data)
{
	GtkWidget *comboboxentry2;
	GtkWidget *comboboxentry3;
	GtkWidget *window12;
	GtkWidget *window15;
	GtkWidget *liste;
	char dispo[30];
	char seance[30];
	char fdispo[30];
	char fseance[30];
	char frole[30];
	FILE *fic;
	FILE *tmp;

	comboboxentry2=lookup_widget(widget,"comboboxentry2");
	comboboxentry3=lookup_widget(widget,"comboboxentry3");
	strcpy(seance,gtk_combo_box_get_active_text(GTK_COMBO_BOX(comboboxentry2)));
	strcpy(dispo,gtk_combo_box_get_active_text(GTK_COMBO_BOX(comboboxentry3)));
	fic=fopen("src/dispo.txt","r");
	tmp=fopen("src/dispo1.txt","w+");
	if (fic!=NULL)
	{
		while(fscanf(fic,"%s %s %s\n",frole, fseance, fdispo)!=EOF)
		{
			if (strcmp(fseance,seance)==0)
				fprintf(tmp,"%s %s %s\n",frole,seance,dispo);
			else
				fprintf(tmp,"%s %s %s\n",frole,fseance,fdispo);
		}
	}
	fclose(fic);
	fclose(tmp);
	rename("src/dispo1.txt","src/dispo.txt");
	window15=lookup_widget(widget,"window15");
	window12 = create_window12 ();
	liste=lookup_widget(window12,"treeview5");
	affichage_dispo(liste);
	gtk_widget_hide(GTK_WIDGET(window15));
	gtk_widget_show(GTK_WIDGET(window12));

}


void on_treeview3_row_activated (GtkWidget *widget, GtkTreePath *path, GtkTreeViewColumn *column, gpointer user_data)
{
	GtkWidget *entry14;
	GtkWidget *entry15;
	GtkWidget *entry16;
	GtkWidget *list_view;
	gchar *alim_evit;
	gchar *alim_dav;
	gchar *alim_mod;
	GtkTreeIter iter;

	entry14=lookup_widget(widget,"entry14");
	entry15=lookup_widget(widget,"entry15");
	entry16=lookup_widget(widget,"entry16");
	list_view=lookup_widget(widget,"treeview3");
	GtkTreeModel *model = gtk_tree_view_get_model (GTK_TREE_VIEW(lookup_widget(widget,"treeview3")));
 	if (gtk_tree_model_get_iter(model, &iter, path))
      gtk_tree_model_get (GTK_TREE_MODEL(model), &iter, 0, &alim_evit, 1, &alim_dav, 2, &alim_mod, -1);
  	gtk_entry_set_text(GTK_ENTRY(entry14),alim_evit);
	gtk_entry_set_text(GTK_ENTRY(entry15),alim_dav);
	gtk_entry_set_text(GTK_ENTRY(entry16),alim_mod);
}


void on_button27_clicked (GtkWidget *widget, gpointer user_data)
{
	GtkWidget *entry14;
	GtkWidget *liste;
	char alim[20];
	char chtmp1[20];
	char chtmp2[20];
	char chtmp3[20];
	FILE *fic;
	FILE *tmp;

	entry14=lookup_widget(widget,"entry14");
	liste=lookup_widget(widget,"treeview3");
	strcpy(alim,gtk_entry_get_text(GTK_ENTRY(entry14)));
	fic=fopen("src/liste_alim.txt","r");
	tmp=fopen("src/liste_alim1.txt","w+");
	while (fscanf(fic,"%s %s %s\n",chtmp1,chtmp2,chtmp3)!=EOF)
	{
		if (strcmp(chtmp1,"-")!=0 || strcmp(chtmp2,"-")!=0 || strcmp(chtmp3,"-")!=0)
		{
			if (strcmp(chtmp2,alim)==0)
				fprintf(tmp,"%s %s %s\n",chtmp1,"-",chtmp3);
			else
				fprintf(tmp,"%s %s %s\n",chtmp1,chtmp2,chtmp3);
		}
	}
	fclose(fic);
	fclose(tmp);
	rename("src/liste_alim1.txt","src/liste_alim.txt");
	affichage_liste_alim(liste);
}


void on_button28_clicked (GtkWidget *widget, gpointer user_data)
{
	GtkWidget *entry16;
	GtkWidget *liste;
	char alim[20];
	char chtmp1[20];
	char chtmp2[20];
	char chtmp3[20];
	FILE *fic;
	FILE *tmp;

	entry16=lookup_widget(widget,"entry16");
	liste=lookup_widget(widget,"treeview3");
	strcpy(alim,gtk_entry_get_text(GTK_ENTRY(entry16)));
	fic=fopen("src/liste_alim.txt","r");
	tmp=fopen("src/liste_alim1.txt","w+");
	while (fscanf(fic,"%s %s %s\n", chtmp1, chtmp2,chtmp3)!=EOF)
	{
		if (strcmp(chtmp1,"-")!=0 || strcmp(chtmp2,"-")!=0 || strcmp(chtmp3,"-")!=0)
		{
			if (strcmp(chtmp3,alim)==0)
				fprintf(tmp,"%s %s %s\n",chtmp1,chtmp2,"-");
			else
				fprintf(tmp,"%s %s %s\n",chtmp1,chtmp2,chtmp3);
		}
	}
	fclose(fic);
	fclose(tmp);
	rename("src/liste_alim1.txt","src/liste_alim.txt");
	affichage_liste_alim(liste);
}


//////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////                                                                                             ////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////







////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////                                                                             ///////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////






void
on_button_Adherant_donne_personnel_clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window_menu_adherant;
GtkWidget *window_donne_personnel;
GtkWidget *output;
GtkWidget *output1;
GtkWidget *List_View;
char log[50];

output= lookup_widget(objet_graphique,"label_adh_menu_adh_login");
strcpy(log,gtk_label_get_text(GTK_LABEL(output)));


window_menu_adherant= lookup_widget(objet_graphique,"window_menu_adherant");
window_donne_personnel=create_window_donne_personnel();
gtk_widget_show (window_donne_personnel);
output1= lookup_widget(window_donne_personnel,"label_adh_donne_personnel_login");
gtk_label_set_text(GTK_LABEL(output1),log);
gtk_widget_destroy (window_menu_adherant);


List_View= lookup_widget(window_donne_personnel,"treeview_adh_regime");
affichage_liste_alim(List_View);



}





//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////                                                                                                    ///////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////





void
on_button_quitter_Adherant_clicked     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
gtk_main_quit();
}





/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////                                                              ///////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////










void
on_button_Adherant_evenement_clicked   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window_menu_adherant;
GtkWidget *window_evenement;
GtkWidget *List_View;
GtkWidget *output;
GtkWidget *output1;

char log[50];

output= lookup_widget(objet_graphique,"label_adh_menu_adh_login");
strcpy(log,gtk_label_get_text(GTK_LABEL(output)));


window_menu_adherant= lookup_widget(objet_graphique,"window_menu_adherant");
window_evenement=create_window_evenement();
gtk_widget_show (window_evenement);
output1= lookup_widget(window_evenement,"label_adh_menu_adh_event");
gtk_label_set_text(GTK_LABEL(output1),log);
gtk_widget_destroy (window_menu_adherant);


List_View= lookup_widget(window_evenement,"treeview_adherant_event");
afficher_event_adh(List_View);


}



///////////////////////////////////////////////////////////////////////////////////////////////////
///////////                                                                               /////////
///////////////////////////////////////////////////////////////////////////////////////////////////




void
on_button_Adherant_seance_clicked      (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window_menu_adherant;
GtkWidget *window_seance;
GtkWidget *listview;
GtkWidget *output;
GtkWidget *output1;

char log[50];

output= lookup_widget(objet_graphique,"label_adh_menu_adh_login");
strcpy(log,gtk_label_get_text(GTK_LABEL(output)));

window_menu_adherant= lookup_widget(objet_graphique,"window_menu_adherant");
window_seance=create_window_seance();
gtk_widget_show (window_seance);
output1= lookup_widget(window_seance,"label_adh_seance_login");
gtk_label_set_text(GTK_LABEL(output1),log);
gtk_widget_destroy (window_menu_adherant);

listview= lookup_widget(window_seance,"treeview_adherant_seance");
afficher_liste_staff_adh(listview,"adherant");

}




////////////////////////////////////////////////////////////////////////////////////////////////////
//////                                                                                     /////////
////////////////////////////////////////////////////////////////////////////////////////////////////









////////////////////////////////////////////////////////////////////////////////////////////////////
//////                                                                                        //////
////////////////////////////////////////////////////////////////////////////////////////////////////












///////////////////////////////////////////////////////////////////////////////////////////////////
////////////                                                                                 //////
///////////////////////////////////////////////////////////////////////////////////////////////////




void
on_button_quitter_inscription_clicked  (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
gtk_main_quit();
}




////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////                                                                     /////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////






//////////////////////////////////////////////////////////////////////////////////////////////////
///////////////                                                                ///////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////



void
on_button_Deconnexion_Adh__rant_clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window_menu_adherant;
GtkWidget *window1;

window_menu_adherant= lookup_widget(objet_graphique,"window_menu_adherant");
window1=create_window1();
gtk_widget_show (window1);
gtk_widget_destroy (window_menu_adherant);
}





////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////                                                                //////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////




void
on_button_adherant_quitter_seance_clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
gtk_main_quit();
}





///////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////                                                                       //////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////





void
on_button_adherant_retour_seance_clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window_menu_adherant;
GtkWidget *window_seance;
GtkWidget *output;
GtkWidget *output1;

char log[50];

output= lookup_widget(objet_graphique,"label_adh_seance_login");
strcpy(log,gtk_label_get_text(GTK_LABEL(output)));

window_seance= lookup_widget(objet_graphique,"window_seance");
window_menu_adherant=create_window_menu_adherant();
gtk_widget_show (window_menu_adherant);
output1= lookup_widget(window_menu_adherant,"label_adh_menu_adh_login");
gtk_label_set_text(GTK_LABEL(output1),log);
gtk_widget_destroy (window_seance);
}




//////////////////////////////////////////////////////////////////////////////////////////////////////
////////////                                                                           ///////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////





void
on_button_adherant_retour_evenement_clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window_menu_adherant;
GtkWidget *window_evenement;
GtkWidget *output;
GtkWidget *output1;

char log[50];

output= lookup_widget(objet_graphique,"label_adh_menu_adh_event");
strcpy(log,gtk_label_get_text(GTK_LABEL(output)));


window_evenement= lookup_widget(objet_graphique,"window_evenement");
window_menu_adherant=create_window_menu_adherant();
gtk_widget_show (window_menu_adherant);
output1= lookup_widget(window_menu_adherant,"label_adh_menu_adh_login");
gtk_label_set_text(GTK_LABEL(output1),log);
gtk_widget_destroy (window_evenement);
}




/////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////                                                                      //////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////




void
on_button_adherant_quitter_evenement_clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
gtk_main_quit();
}





///////////////////////////////////////////////////////////////////////////////////////////////////////
///////////                                                                           //////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////

void
on_button_adherant_quitter_donne_personnel_clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
gtk_main_quit();
}



////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////                                                                           ///////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////





void
on_button_adherant_retour_donn__e_personnel_clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window_menu_adherant;
GtkWidget *window_donne_personnel;
GtkWidget *output;
GtkWidget *output1;

char log[50];

output= lookup_widget(objet_graphique,"label_adh_donne_personnel_login");
strcpy(log,gtk_label_get_text(GTK_LABEL(output)));


window_donne_personnel= lookup_widget(objet_graphique,"window_donne_personnel");
window_menu_adherant=create_window_menu_adherant();
gtk_widget_show (window_menu_adherant);
output1= lookup_widget(window_menu_adherant,"label_adh_menu_adh_login");
gtk_label_set_text(GTK_LABEL(output1),log);
gtk_widget_destroy (window_donne_personnel);
}





///////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////                                                                               ///////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////





void
on_button_adh_menu_adh_profil_clicked  (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window_menu_adherant;
GtkWidget *window_adh_profil;
GtkWidget *output;
GtkWidget *output1;


char log[50];




output= lookup_widget(objet_graphique,"label_adh_menu_adh_login");
strcpy(log,gtk_label_get_text(GTK_LABEL(output)));


window_menu_adherant= lookup_widget(objet_graphique,"window_menu_adherant");
window_adh_profil=create_window_adh_profil();
gtk_widget_show (window_adh_profil);
output1= lookup_widget(window_adh_profil,"label_adh_profil_login");
gtk_label_set_text(GTK_LABEL(output1),log);
gtk_widget_destroy (window_menu_adherant);


GtkWidget *input1;
GtkWidget *input2;
GtkWidget *input3;
GtkWidget *input4;
GtkWidget *input5;
		    
char var4[50];
char var1[50];
char var2[50];
char var3[50];
char var5[50];

input1=lookup_widget(window_adh_profil, "entry_adh_profil_nom");
input2=lookup_widget(window_adh_profil, "entry_adh_profil_prenom");
input3=lookup_widget(window_adh_profil, "entry_adh_profil_sexe");
input4=lookup_widget(window_adh_profil, "entry_adh_profil_Age");
input5=lookup_widget(window_adh_profil, "label_adh_profil_login");

FILE *fic;
fic=fopen("src/profile.txt","r");

if (fic==NULL) printf("erreur\n");
else {
while (fscanf(fic,"%s %s %s %s %s",var1,var2,var3,var4,var5)!=EOF)
{ 
break;
}
fclose(fic);}
if(strcmp(var1,log)==0)
//{
gtk_entry_set_text(GTK_ENTRY(input1),var2);
gtk_entry_set_text(GTK_ENTRY(input2),var3);
gtk_entry_set_text(GTK_ENTRY(input3),var4);
gtk_entry_set_text(GTK_ENTRY(input4),var5);

//}
}




////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////                                                                            //////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////





void
on_button_adherant_seance_modifetsupp_clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window_seance;
GtkWidget *window_adh_gestion_seance;
GtkWidget *List_View;
GtkWidget *output;
GtkWidget *output1;

char log[50];
char type;

output= lookup_widget(objet_graphique,"label_adh_seance_login");
strcpy(log,gtk_label_get_text(GTK_LABEL(output)));




window_seance= lookup_widget(objet_graphique,"window_seance");
window_adh_gestion_seance=create_window_adh_gestion_seance();
gtk_widget_show (window_adh_gestion_seance);
output1= lookup_widget(window_adh_gestion_seance,"label_adh_gestseance_login");
gtk_label_set_text(GTK_LABEL(output1),log);
gtk_widget_destroy (window_seance);

List_View=lookup_widget(window_adh_gestion_seance,"treeview_adh_gestionseance");
afficher_particip_seance_adh(List_View,"adherant");
}





/////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////                                                                             ///////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////

void
on_button_adh_event_supp_clicked       (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

}




//////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////                                                                                           ///////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////


void
on_button_adh_event_modifier_clicked   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

}





//////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////                                                                           ////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////




void
on_button_adh_event_ajout_clicked      (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
char log[50];char event[50];char jr[50]; char mois[50]; char ans[50]; char hr[50];FILE* f;

GtkWidget *input1;
GtkWidget *input2;
GtkWidget *input3;
GtkWidget *input4;
GtkWidget *input5;
GtkWidget *listeview;
GtkWidget *treeview_adherant_event;

GtkWidget *window_evenement;


window_evenement= lookup_widget(objet_graphique,"window_evenement");
input1= lookup_widget(objet_graphique,"entry_adh_event_event");
input2= lookup_widget(objet_graphique,"combobox_adh_event_jr");
input3= lookup_widget(objet_graphique,"combobox_adh_event_mois");
input4= lookup_widget(objet_graphique,"combobox_adh_event_ans");
input5= lookup_widget(objet_graphique,"combobox_adh_event_hr");


strcpy(event,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(jr,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input2)));
strcpy(mois,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input3)));
strcpy(ans,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input4)));
strcpy(hr,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input5)));


ajout_participe_event_adh(event,jr,mois,ans,hr);

}


///////////////////////////////////////////////////////////////////////////////////////
/////////////                                                                  ////////
///////////////////////////////////////////////////////////////////////////////////////




void
on_button_adh_gestseance_return_clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window_adh_gestion_seance;
GtkWidget *window_seance;
GtkWidget *output;
GtkWidget *output1;

char log[50];

output= lookup_widget(objet_graphique,"label_adh_gestseance_login");
strcpy(log,gtk_label_get_text(GTK_LABEL(output)));


window_adh_gestion_seance= lookup_widget(objet_graphique,"window_adh_gestion_seance");
window_seance=create_window_seance();
gtk_widget_show (window_seance);
output1= lookup_widget(window_seance,"label_adh_seance_login");
gtk_label_set_text(GTK_LABEL(output1),log);
gtk_widget_destroy (window_adh_gestion_seance);
}




///////////////////////////////////////////////////////////////////////////////////////////
/////////////                                                         /////////////////////
///////////////////////////////////////////////////////////////////////////////////////////


void
on_button_adh_gestseance_quitter_clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
gtk_main_quit();
}





//////////////////////////////////////////////////////////////////////////////////////////
///////////////                                                           ////////////////
//////////////////////////////////////////////////////////////////////////////////////////



void
on_button_adh_gestseance_modifier_clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	GtkWidget *input1;
	GtkWidget *input2;	
	GtkWidget *input3;
	GtkWidget *input4;
	GtkWidget *input5;
	GtkWidget *listeview;
	GtkWidget *window_adh_gestion_seance;

	char type[50],jour[50],mois[50],annee[50],heure[50];

	window_adh_gestion_seance = lookup_widget(objet_graphique,"window_adh_gestion_seance");



input1 = lookup_widget(objet_graphique,"entry_adh_gestseance_type");
input2=lookup_widget(objet_graphique,"entry_adh_gestseance_jr");
input3=lookup_widget(objet_graphique,"entry_adh_gestseance_mois");
input4=lookup_widget(objet_graphique,"entry_adh_gestseance_ans");
input5=lookup_widget(objet_graphique,"entry_adh_gestseance_hr");

strcpy(type,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(jour,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(mois,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(annee,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(heure,gtk_entry_get_text(GTK_ENTRY(input5)));
modifier_comptes_adh(type,jour,mois,annee,heure);

listeview=lookup_widget(window_adh_gestion_seance,"treeview_adh_gestionseance");
afficher_particip_seance_adh(listeview, "Adherant");
}





//////////////////////////////////////////////////////////////////////////////////////////
////////////////                                                           ///////////////
//////////////////////////////////////////////////////////////////////////////////////////



void
on_button_adh_gestseance_supp_clicked  (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	GtkWidget *input1;
	GtkWidget *input2;	
	GtkWidget *input3;
	GtkWidget *input4;
	GtkWidget *input5;
	GtkWidget *listeview;
	GtkWidget *window_adh_gestion_seance;

	char type[50],jour[50],mois[50],annee[50],heure[50];

	window_adh_gestion_seance = lookup_widget(objet_graphique,"window_adh_gestion_seance");



input1 = lookup_widget(objet_graphique,"entry_adh_gestseance_type");
input2=lookup_widget(objet_graphique,"entry_adh_gestseance_jr");
input3=lookup_widget(objet_graphique,"entry_adh_gestseance_mois");
input4=lookup_widget(objet_graphique,"entry_adh_gestseance_ans");
input5=lookup_widget(objet_graphique,"entry_adh_gestseance_hr");

strcpy(type,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(jour,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(mois,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(annee,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(heure,gtk_entry_get_text(GTK_ENTRY(input5)));
supprimer_adh(type,jour,mois,annee,heure);

listeview=lookup_widget(window_adh_gestion_seance,"treeview_adh_gestionseance");
afficher_particip_seance_adh(listeview, "adherant");
}





////////////////////////////////////////////////////////////////////////////////////////////
////////////////                                                          //////////////////
////////////////////////////////////////////////////////////////////////////////////////////




void
on_button_adh_event_participate_clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window_adh_gestevent;
GtkWidget *window_evenement;
GtkWidget *listeview;
GtkWidget *output;
GtkWidget *output1;

char log[50];

output= lookup_widget(objet_graphique,"label_adh_menu_adh_event");
strcpy(log,gtk_label_get_text(GTK_LABEL(output)));

window_evenement= lookup_widget(objet_graphique,"window_evenement");
window_adh_gestevent=create_window_adh_gestevent();
gtk_widget_show (window_adh_gestevent);
output1= lookup_widget(window_adh_gestevent,"label_adh_gest_event_login");
gtk_label_set_text(GTK_LABEL(output1),log);
gtk_widget_destroy (window_evenement);

listeview=lookup_widget(window_adh_gestevent,"treeview_adherant_gestevent");
afficher_participe_event_adh(listeview);
}




///////////////////////////////////////////////////////////////////////////////////////////
///////////////                                                           /////////////////
///////////////////////////////////////////////////////////////////////////////////////////



void
on_button_adh_grstevent_retour_clicked (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window_adh_gestevent;
GtkWidget *window_evenement;
GtkWidget *output;
GtkWidget *output1;

char log[50];

output= lookup_widget(objet_graphique,"label_adh_gest_event_login");
strcpy(log,gtk_label_get_text(GTK_LABEL(output)));


window_adh_gestevent= lookup_widget(objet_graphique,"window_adh_gestevent");
window_evenement=create_window_evenement();
gtk_widget_show (window_evenement);
output1= lookup_widget(window_evenement,"label_adh_menu_adh_event");
gtk_label_set_text(GTK_LABEL(output1),log);
gtk_widget_destroy (window_adh_gestevent);
}



///////////////////////////////////////////////////////////////////////////////////////////
//////                                                                            /////////
///////////////////////////////////////////////////////////////////////////////////////////



void
on_button_adh_grstevent_modif_clicked  (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *input1;
	GtkWidget *input2;	
	GtkWidget *input3;
	GtkWidget *input4;
	GtkWidget *input5;
	GtkWidget *listeview;
	GtkWidget *window_adh_gestevent;

	char event[50],jour[50],mois[50],annee[50],heure[50];

	window_adh_gestevent = lookup_widget(objet_graphique,"window_adh_gestevent");



input1 = lookup_widget(objet_graphique,"entry_adh_gestevent_event");
input2=lookup_widget(objet_graphique,"entry_adh_gestevent_jr");
input3=lookup_widget(objet_graphique,"entry_adh_gestevent_mois");
input4=lookup_widget(objet_graphique,"entry_adh_gestevent_ans");
input5=lookup_widget(objet_graphique,"entry_adh_gestevent_hr");

strcpy(event,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(jour,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(mois,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(annee,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(heure,gtk_entry_get_text(GTK_ENTRY(input5)));
modifier_participe_event_adh(event,jour,mois,annee,heure);

listeview=lookup_widget(window_adh_gestevent,"treeview_adherant_gestevent");
afficher_participe_event_adh(listeview);
}





/////////////////////////////////////////////////////////////////////////////////////////////
///////////////                                                            //////////////////
/////////////////////////////////////////////////////////////////////////////////////////////



void
on_button_adh_grstevent_supp_clicked   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	GtkWidget *input1;
	GtkWidget *input2;	
	GtkWidget *input3;
	GtkWidget *input4;
	GtkWidget *input5;
	GtkWidget *listeview;
	GtkWidget *window_adh_gestevent;

	char event[50],jour[50],mois[50],annee[50],heure[50];

	window_adh_gestevent = lookup_widget(objet_graphique,"window_adh_gestevent");



input1 = lookup_widget(objet_graphique,"entry_adh_gestevent_event");
input2=lookup_widget(objet_graphique,"entry_adh_gestevent_jr");
input3=lookup_widget(objet_graphique,"entry_adh_gestevent_mois");
input4=lookup_widget(objet_graphique,"entry_adh_gestevent_ans");
input5=lookup_widget(objet_graphique,"entry_adh_gestevent_hr");

strcpy(event,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(jour,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(mois,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(annee,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(heure,gtk_entry_get_text(GTK_ENTRY(input5)));
supp_participe_event_adh(event,jour,mois,annee,heure);

listeview=lookup_widget(window_adh_gestevent,"treeview_adherant_gestevent");
afficher_participe_event_adh(listeview);
}



///////////////////////////////////////////////////////////////////////////////////////////////////
///////////                                                                          //////////////
//////////////////////////////////////////////////////////////////////////////////////////////////




void
on_combobox_adh_seance_type_changed    (GtkWidget     *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *combobox_adh_seance_type;
GtkWidget *window_seance;
GtkWidget *listeview;
char role[50];


combobox_adh_seance_type=lookup_widget(objet_graphique, "combobox_adh_seance_type");
window_seance=lookup_widget(objet_graphique, "window_seance");
strcpy(role,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_adh_seance_type)));
listeview = lookup_widget(window_seance,"treeview_adherant_seance");

GtkTreeModel *model = gtk_tree_view_get_model(GTK_TREE_VIEW(listeview));
gtk_list_store_clear(model);
if (strcmp(role,"Coach")==0)
{
//gtk_widget_destroy(listeview);

//listeview = gtk_tree_view_new();
//init_listeview(listeview);
afficher_liste_staff_adh(listeview,"Coach");
}

else if(strcmp(role,"Dietheticien")==0)
{
afficher_liste_staff_adh(listeview,"Dietheticien");
}
else if(strcmp(role,"Medecin")==0)
{
afficher_liste_staff_adh(listeview,"Medecin");
}
else if(strcmp(role,"Kinethearapiste")==0)
{
afficher_liste_staff_adh(listeview,"Kinethearapiste");
}
}


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////                                   /////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void
on_button_adherant_seance_ajout_clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
char type[50];char jour[50]; char mois[50]; char ans[50]; char hr[50];FILE* f;

GtkWidget *input1;
GtkWidget *input2;
GtkWidget *input3;
GtkWidget *input4;
GtkWidget *input5;


GtkWidget *window_seance;


window_seance= lookup_widget(objet_graphique,"window_seance");
input1= lookup_widget(objet_graphique,"combobox_adh_seance_type");
input2= lookup_widget(objet_graphique,"combobox_adh_seance_jr");
input3= lookup_widget(objet_graphique,"combobox_adh_seance_mois");
input4= lookup_widget(objet_graphique,"combobox_adh_seance_ann");
input5= lookup_widget(objet_graphique,"combobox_adh_seance_hr");


strcpy(type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input1)));
strcpy(jour,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input2)));
strcpy(mois,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input3)));
strcpy(ans,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input4)));
strcpy(hr,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input5)));


ajout_seance_adh(type,jour,mois,ans,hr);
}




/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////                                                                                                                //////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////







void
on_treeview_adherant_gestevent_row_activated
                                        (GtkWidget     *objet_graphique,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
	gchar *event;
  	gchar *jour;
	gchar *mois;
	gchar *annee;
	gchar *heure;
   
	GtkWidget *input1;
	GtkWidget *input2;	
	GtkWidget *input3;
	GtkWidget *input4;
	GtkWidget *input5;
	GtkWidget *window_adh_gestevent;
		GtkWidget *listeview;
   GtkTreeIter iter;

listeview = lookup_widget(objet_graphique,"treeview_adherant_gestevent");

GtkTreeModel *model = gtk_tree_view_get_model (GTK_TREE_VIEW(lookup_widget(objet_graphique,"treeview_adherant_gestevent")));
 

   if (gtk_tree_model_get_iter(model, &iter, path)) {
      gtk_tree_model_get (GTK_LIST_STORE(model), &iter, 0, &event, 1, &jour,2,&mois,3,&annee,4,&heure, -1);

                                                       }
window_adh_gestevent = lookup_widget(objet_graphique,"window_adh_gestevent");
input1 = lookup_widget(window_adh_gestevent,"entry_adh_gestevent_event");
input2=lookup_widget(window_adh_gestevent,"entry_adh_gestevent_jr");
input3=lookup_widget(window_adh_gestevent,"entry_adh_gestevent_mois");
input4=lookup_widget(window_adh_gestevent,"entry_adh_gestevent_ans");
input5=lookup_widget(window_adh_gestevent,"entry_adh_gestevent_hr");

gtk_entry_set_text(GTK_ENTRY(input1),event);
gtk_entry_set_text(GTK_ENTRY(input2),jour);
gtk_entry_set_text(GTK_ENTRY(input3),mois);
gtk_entry_set_text(GTK_ENTRY(input4),annee);
gtk_entry_set_text(GTK_ENTRY(input5),heure);	

}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////                                                      /////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

on_treeview_adh_gestionseance_row_activated
					(GtkWidget     *objet_graphique,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)





{
gchar *type;
  	gchar *jour;
	gchar *mois;
	gchar *annee;
	gchar *heure;
   
	GtkWidget *input1;
	GtkWidget *input2;	
	GtkWidget *input3;
	GtkWidget *input4;
	GtkWidget *input5;
	GtkWidget *window_adh_gestion_seance;
		GtkWidget *listeview;
   GtkTreeIter iter;

listeview = lookup_widget(objet_graphique,"treeview_adh_gestionseance");

GtkTreeModel *model = gtk_tree_view_get_model (GTK_TREE_VIEW(lookup_widget(objet_graphique,"treeview_adh_gestionseance")));
 

   if (gtk_tree_model_get_iter(model, &iter, path)) {
      gtk_tree_model_get (GTK_LIST_STORE(model), &iter, 0, &type, 1, &jour,2,&mois,3,&annee,4,&heure, -1);

                                                       }
window_adh_gestion_seance = lookup_widget(objet_graphique,"window_adh_gestion_seance");
input1 = lookup_widget(window_adh_gestion_seance,"entry_adh_gestseance_type");
input2=lookup_widget(window_adh_gestion_seance,"entry_adh_gestseance_jr");
input3=lookup_widget(window_adh_gestion_seance,"entry_adh_gestseance_mois");
input4=lookup_widget(window_adh_gestion_seance,"entry_adh_gestseance_ans");
input5=lookup_widget(window_adh_gestion_seance,"entry_adh_gestseance_hr");

gtk_entry_set_text(GTK_ENTRY(input1),type);
gtk_entry_set_text(GTK_ENTRY(input2),jour);
gtk_entry_set_text(GTK_ENTRY(input3),mois);
gtk_entry_set_text(GTK_ENTRY(input4),annee);
gtk_entry_set_text(GTK_ENTRY(input5),heure);
}


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////                                                          /////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



on_treeview_adherant_evenement_row_activated
                                        (GtkWidget     *objet_graphique,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////                                                                                                            ////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



void
on_button_adh_profil_modif_clicked     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	/*GtkWidget *input1;
	GtkWidget *input2;	
	GtkWidget *input3;
	GtkWidget *input4;
	
	char log[50];

	GtkWidget *output;
	GtkWidget *output1;

	GtkWidget *window_adh_profil;

	char nom[50],prenom[50],sexe[50],age[50];

	window_adh_profil = lookup_widget(objet_graphique,"window_adh_profil");

	output= lookup_widget(objet_graphique,"label_adh_profil_login");
	strcpy(log,gtk_label_get_text(GTK_LABEL(output)));


	input1 = lookup_widget(objet_graphique,"entry_adh_profil_nom");
	input2=lookup_widget(objet_graphique,"entry_adh_profil_prenom");
	input3=lookup_widget(objet_graphique,"entry_adh_profil_sexe");
	input4=lookup_widget(objet_graphique,"entry_adh_profil_Age");

	strcpy(nom,gtk_entry_get_text(GTK_ENTRY(input1)));
	strcpy(prenom,gtk_entry_get_text(GTK_ENTRY(input2)));
	strcpy(sexe,gtk_entry_get_text(GTK_ENTRY(input3)));
	strcpy(age,gtk_entry_get_text(GTK_ENTRY(input4)));

	modifier_adh_profil(nom,prenom,sexe,age);

*/

}



/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////                                                                                                            ////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////




void
on_button_adh_profil_quitter_clicked   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
gtk_main_quit();
}


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////                                                                                                            ////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////




void
on_button_adh_profil_retour_clicked    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window_menu_adherant;
GtkWidget *window_adh_profil;
GtkWidget *output;
GtkWidget *output1;

char log[50];

output= lookup_widget(objet_graphique,"label_adh_profil_login");
strcpy(log,gtk_label_get_text(GTK_LABEL(output)));


window_adh_profil= lookup_widget(objet_graphique,"window_adh_profil");
window_menu_adherant=create_window_menu_adherant();
gtk_widget_show(window_menu_adherant);
output1= lookup_widget(window_menu_adherant,"label_adh_menu_adh_login");
gtk_label_set_text(GTK_LABEL(output1),log);
gtk_widget_hide (window_adh_profil);
}





///////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////kinetherapiste//////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////


void
on_button_kine_rendezvous_clicked     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)

{

GtkWidget *window_menu_kine,*List_View;
GtkWidget *window_liste_rendez_vous_kine;

window_menu_kine= lookup_widget(objet_graphique,"window_menu_kine");

window_liste_rendez_vous_kine=create_window_liste_rendez_vous_kine();
gtk_widget_show (window_liste_rendez_vous_kine);
gtk_widget_hide (window_menu_kine);
List_View=lookup_widget(window_liste_rendez_vous_kine,"treeview1");
afficher1_kine(List_View);


}


void
on_button_kine_disponibilte_supp_clicked    (GtkWidget       *objet_graphique,
                                              gpointer         user_data) 

                                        
{

GtkWidget *window_disponibilite_kine;
GtkWidget *window_supprimer_disponibilite_kine;

window_disponibilite_kine= lookup_widget(objet_graphique,"disponibilite_kine");

window_supprimer_disponibilite_kine=create_window_supprimer_disponibilite_kine();
gtk_widget_show (window_supprimer_disponibilite_kine);
gtk_widget_hide (window_disponibilite_kine);

}


void
on_button_kine_disponibilte_ajout_clicked
                                           (GtkWidget       *objet_graphique,
                                              gpointer         user_data)

{

GtkWidget *window_disponibilite_kine;
GtkWidget *window_ajouter_disponibilite_kine;

window_disponibilite_kine= lookup_widget(objet_graphique,"disponibilite_kine");

window_ajouter_disponibilite_kine=create_window_ajouter_disponibilite_kine();
gtk_widget_show (window_ajouter_disponibilite_kine);
gtk_widget_hide (window_disponibilite_kine);

}


void
on_button_kine_disponibilite_retour_clicked
                                             (GtkWidget       *objet_graphique,
                                                 gpointer         user_data)

{

GtkWidget *window_disponibilite_kine;
GtkWidget *window_menu_kine;

window_disponibilite_kine= lookup_widget(objet_graphique,"window_disponibilite_kine");

window_menu_kine=create_window_menu_kine();
gtk_widget_show (window_menu_kine);
gtk_widget_hide (window_disponibilite_kine);


}


void
on_button_kine_disponibilite_clicked   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)

{

GtkWidget *window_menu_kine,*List_View ;
GtkWidget *window_disponibilite_kine;

window_menu_kine= lookup_widget(objet_graphique,"window_menu_kine");

window_disponibilite_kine=create_window_disponibilite_kine();
gtk_widget_show (window_disponibilite_kine);
gtk_widget_hide (window_menu_kine);
List_View=lookup_widget(window_disponibilite_kine,"treeview2");
afficher2_kine(List_View);

}


void
on_button_kine_disponibilite_mod_clicked
                                      (GtkWidget       *objet_graphique,
                                        gpointer         user_data)

{

GtkWidget *window_disponibilite_kine;
GtkWidget *window_modifier_disponibilite_kine;

window_disponibilite_kine= lookup_widget(objet_graphique,"window_disponibilite_kine");

window_modifier_disponibilite_kine=create_window_modifier_disponibilite_kine();
gtk_widget_show (window_modifier_disponibilite_kine);
gtk_widget_hide (window_disponibilite_kine);

}


void
on_button_ajouter_dispo_kine_retour_clicked
                                       (GtkWidget       *objet_graphique,
                                        gpointer         user_data)

{

GtkWidget *window_ajouter_disponibilite_kine;
GtkWidget *window_disponibilite_kine;

window_ajouter_disponibilite_kine= lookup_widget(objet_graphique,"window_ajouter_disponibilite_kine");
window_disponibilite_kine=create_window_disponibilite_kine();
gtk_widget_show (window_disponibilite_kine);
gtk_widget_hide (window_ajouter_disponibilite_kine);


}


void
on_button_supp_disp_kine_retour_clicked
                                         (GtkWidget       *objet_graphique,
                                        gpointer         user_data)

{

GtkWidget *window_supprimer_disponibilite_kine;
GtkWidget *window_disponibilite_kine;

window_supprimer_disponibilite_kine= lookup_widget(objet_graphique,"window_supprimer_disponibilite_kine");
window_disponibilite_kine=create_window_disponibilite_kine();
gtk_widget_show (window_disponibilite_kine);
gtk_widget_hide (window_supprimer_disponibilite_kine);


}


void
on_button_mod_disp_kine_retour_clicked  (GtkWidget       *objet_graphique,
                                        gpointer         user_data)

{

GtkWidget *window_modifier_disponibilite_kine;
GtkWidget *window_disponibilite_kine;

window_modifier_disponibilite_kine= lookup_widget(objet_graphique,"window_modifier_disponibilite_kine");
window_disponibilite_kine=create_window_disponibilite_kine();
gtk_widget_show (window_disponibilite_kine);
gtk_widget_hide (window_modifier_disponibilite_kine);

}


void
on_button_liste_rendez_vous_retour_clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data)

{

GtkWidget *window_liste_rendez_vous_kine;
GtkWidget *window_menu_kine;

window_liste_rendez_vous_kine= lookup_widget(objet_graphique,"window_liste_rendez_vous_kine");
window_menu_kine=create_window_menu_kine();
gtk_widget_show (window_menu_kine);
gtk_widget_hide (window_liste_rendez_vous_kine);

}










void
on_button_kine_disponibilite_actualiser_clicked
                                                 (GtkWidget      *objet_graphique,
                                                      gpointer         user_data)

{ 
GtkWidget *List_View;
List_View=lookup_widget(objet_graphique,"treeview2");
afficher2_kine(List_View);
}













void
on_button_kine_menu_retour_clicked     (GtkWidget      *objet_graphique,
                                         gpointer         user_data)
{

GtkWidget *window_menu_kine;
GtkWidget *window1;

window_menu_kine= lookup_widget(objet_graphique,"window_menu_kine");
window1=create_window1();
gtk_widget_show (window1);
gtk_widget_hide (window_menu_kine);

}





void
on_button_kine_ajouter_disponibilite_clicked
                                        (GtkWidget      *objet_graphique,
                                         gpointer         user_data)
{
GtkWidget *jour;
GtkWidget *mois;
GtkWidget *annee;
GtkWidget *Heurs;

int jr;int moi;int ann;char hr[50];
jour=lookup_widget(objet_graphique,"spinbutton_kine_ajout_dispo_jour");
mois=lookup_widget(objet_graphique,"spinbutton_kine_ajout_dispo_mois");
annee=lookup_widget(objet_graphique,"spinbutton_kine_ajout_dispo_annee");
Heurs=lookup_widget(objet_graphique,"combobox1");

jr=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
moi=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
ann=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
strcpy(hr,gtk_combo_box_get_active_text(GTK_COMBO_BOX(Heurs)));

ajouter_dispo_kine(jr,moi,ann,hr);

}


void
on_button_kine_supprimer_disponibilite_clicked
                                         (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
int jour;
int mois;
int annee;
char Heurs[5];
char Heurs1[5];
GtkWidget *combobox;
combobox = lookup_widget(objet_graphique,"combobox2");
strcpy (Heurs1, gtk_combo_box_get_active_text (GTK_COMBO_BOX(combobox)));
//Suppression
FILE* ff1;
FILE* ff2;
ff1=fopen("src/dispo_kine.txt","r");
ff2=fopen("src/dispo_tmp.txt","a+");

if (ff1!=NULL)
	{
	while (fscanf(ff1,"%d %d %d %s",&jour,&mois,&annee,Heurs)!=EOF)
	{
		if (strcmp(Heurs,Heurs1)!=0)
{

	fprintf(ff2,"%d %d %d %s\n",jour,mois,annee,Heurs);
}
	}
}
	
fclose(ff1);
fclose(ff2);
remove("src/dispo_kine.txt");
rename("src/dispo_tmp.txt","src/dispo_kine.txt");
}


void
on_button_kine_actualiser_supprimer_disponibilite_clicked
                                         (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
int jour;
int mois;
int annee;
char Heurs[5];
char Heurs1[5];
GtkWidget *combobox;
combobox = lookup_widget(objet_graphique,"combobox2");
//Recuperation des données
FILE* f;
f=fopen("src/dispo_kine.txt","r");
if (f!=NULL)
{
	while (fscanf(f,"%d %d %d %s\n",&jour,&mois,&annee,Heurs)!=EOF)
	{
           gtk_combo_box_append_text (GTK_COMBO_BOX(combobox),Heurs);
	}	
	}

fclose(f);


}


void
on_button_kine_confirmer_modifier_disponibilite_clicked
                                        (GtkWidget      *objet_graphique,
                                         gpointer         user_data)
{
int jour;
int mois;
int annee;
char Heurs[5];
int jour1;
int mois1;
int annee1;
char Heurs1[5];
GtkWidget *combobox;
combobox = lookup_widget(objet_graphique,"combobox3");
strcpy (Heurs1, gtk_combo_box_get_active_text (GTK_COMBO_BOX(combobox)));

//Suppression
FILE* ff1;
FILE* ff2;
ff1=fopen("src/dispo_kine.txt","r");
ff2=fopen("src/dispo_tmp.txt","a+");

if (ff1!=NULL)
	{
	while (fscanf(ff1,"%d %d %d %s\n",&jour,&mois,&annee,Heurs)!=EOF)
	{
		if (strcmp(Heurs,Heurs1)!=0)
{
	fprintf(ff2,"%d %d %d %s\n",jour,mois,annee,Heurs);
}
               

        
	}
	}
fclose(ff1);
fclose(ff2);
ff1=fopen("src/dispo_kine.txt","r");
rename("src/dispo_tmp.txt","src/dispo_kine.txt");

}


void
on_button_kine_actualiser_modifier_disponibilite_clicked
                                        (GtkWidget      *objet_graphique,
                                         gpointer         user_data)
{
int jour;
int mois;
int annee;
char Heurs[5];
GtkWidget *combobox;
combobox = lookup_widget(objet_graphique,"combobox3");
//Recuperation des données
FILE* f;
f=fopen("src/dispo_kine.txt","r");
if (f!=NULL)
{
	while (fscanf(f,"%d %d %d %s\n",&jour,&mois,&annee,Heurs)!=EOF)
	{

	gtk_combo_box_append_text (GTK_COMBO_BOX(combobox),Heurs);
	}	
	
}
fclose(f);

}


void
on_button_kine_modifier_disponibilite_clicked
                                        (GtkWidget      *objet_graphique,
                                         gpointer         user_data)
{
GtkWidget *jour;
GtkWidget *mois;
GtkWidget *annee;
GtkWidget *Heurs;

int jr;int moi;int ann;char hr[50];
jour=lookup_widget(objet_graphique,"spinbutton3");
mois=lookup_widget(objet_graphique,"spinbutton2");
annee=lookup_widget(objet_graphique,"spinbutton1");
Heurs=lookup_widget(objet_graphique,"comboboxentry3");

jr=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
moi=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
ann=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
strcpy(hr,gtk_combo_box_get_active_text(GTK_COMBO_BOX(Heurs)));

ajouter_dispo_kine(jr,moi,ann,hr);

}

