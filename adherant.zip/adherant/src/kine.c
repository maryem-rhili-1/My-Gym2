#include<string.h>
#include <stdio.h>
#include <stdlib.h>
#include "kine.h"


void ajouter_dispo_kine(int jour,int mois,int annee,char Heurs[50])
{
FILE *f;

f=fopen("src/dispo_kine.txt","a+");

		fprintf(f,"%d %d %d %s\n",jour,mois,annee,Heurs);
fclose(f);
}


void afficher1_kine(GtkWidget *filistview)
{ 
enum { COL_NOM,
       COL_PRENOM,
       COL_CIN,
       COL_DATE,
       COL_AGE,
       COL_ADRESSE,
       NUM_COLS
      };
char nom[20],prenom[20],cin[8],date[30],adresse[50];int age;
GtkListStore *liststore;
GtkCellRenderer *celrender;
GtkTreeViewColumn *col;
GtkTreeIter *iter;
liststore = gtk_list_store_new(NUM_COLS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_STRING);
FILE *f;
f=fopen("src/rdv_kine.txt","r");
if(f!=NULL){
       while(fscanf(f,"%s %s %s %s %d %s",nom,prenom,cin,date,&age,adresse)!=EOF){
           GtkTreeIter iter;
            gtk_list_store_append(liststore, &iter);
            gtk_list_store_set(liststore, &iter,
                          COL_NOM, nom,
		          COL_PRENOM, prenom,
		          COL_CIN, cin,
			  COL_DATE,date,
			  COL_AGE,age,
			  COL_ADRESSE,adresse,
                       -1);}
	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("nom",celrender,"text",COL_NOM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(filistview),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("prenom",celrender,"text",COL_PRENOM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(filistview),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("cin",celrender,"text",COL_CIN,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(filistview),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("date",celrender,"text",COL_DATE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(filistview),col);
	
	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("age",celrender,"text",COL_AGE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(filistview),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("adresse",celrender,"text",COL_ADRESSE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(filistview),col);
	
	gtk_tree_view_set_model (GTK_TREE_VIEW(filistview), GTK_TREE_MODEL (liststore));

}
fclose(f);
}

void supprimer_dispo_kine(int jour,int mois,int annee,char Heurs[50],char Heurs1[50])

{
FILE* f1;
FILE* f2;
f1=fopen("src/dispo_kine.txt","r");
f2=fopen("src/dispo_tmp.txt","a+");
if (f1!=NULL)
	{
	while (fscanf(f1,"%d %d %d %s \n",&jour,&mois,&annee,Heurs)!=EOF)
	{
		if (strcmp(Heurs,Heurs1)!=0)
{
	fprintf(f2,"%d %d %d %s \n",jour,mois,annee,Heurs);
}
	}
	}
fclose(f1);
fclose(f2);
remove("src/dispo_tmp.txt");
rename("src/dispo_kine.txt","src/dispo_tmp.txt");
}



void afficher2_kine(GtkWidget *filistview)
{ 
enum { COL_JOUR,
       COL_MOIS,
       COL_ANNEE,
       COL_HEURS,
       NUM_COLS
      };
int jour;
int mois;
int annee;
char Heurs[50];
GtkListStore *liststore;
GtkCellRenderer *celrender;
GtkTreeViewColumn *col;
GtkTreeIter *iter;
liststore = gtk_list_store_new(NUM_COLS,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_STRING);
FILE *f;
f=fopen("src/dispo_kine.txt","r");
if(f!=NULL){
       while(fscanf(f,"%d %d %d %s",&jour,&mois,&annee,Heurs)!=EOF){
            GtkTreeIter iter;
            gtk_list_store_append(liststore, &iter);
            gtk_list_store_set(liststore, &iter,
                COL_JOUR,jour,
       		COL_MOIS,mois,
       		COL_ANNEE,annee,
       		COL_HEURS,Heurs,
               -1);}
	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("jour",celrender,"text",COL_JOUR,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(filistview),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("mois",celrender,"text",COL_MOIS,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(filistview),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("annee",celrender,"text",COL_ANNEE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(filistview),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("Heurs",celrender,"text",COL_HEURS,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(filistview),col);


	gtk_tree_view_set_model (GTK_TREE_VIEW(filistview), GTK_TREE_MODEL (liststore));

}
fclose(f);

}

