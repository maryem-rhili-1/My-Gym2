#include <gtk/gtk.h>



void on_button1_clicked (GtkWidget *widget, gpointer user_data);

void on_button2_clicked (GtkWidget *widget, gpointer user_data);

void on_button3_clicked (GtkWidget *widget, gpointer user_data);

void on_button4_clicked (GtkWidget *widget, gpointer user_data);

void on_button5_clicked (GtkWidget *widget, gpointer user_data);

void on_button6_clicked (GtkWidget *widget, gpointer user_data);

void on_button7_clicked (GtkWidget *widget, gpointer user_data);

void on_button9_clicked (GtkWidget *widget, gpointer user_data);

void on_button8_clicked (GtkWidget *widget, gpointer user_data);

void on_button10_clicked (GtkWidget *widget, gpointer user_data);

void on_button11_clicked (GtkWidget *widget, gpointer user_data);

void on_button13_clicked (GtkWidget *widget, gpointer user_data);

void on_button14_clicked (GtkWidget *widget, gpointer user_data);

void on_button15_clicked (GtkWidget *widget, gpointer user_data);

void on_button16_clicked (GtkWidget *widget, gpointer user_data);

void on_button17_clicked (GtkWidget *widget, gpointer user_data);

void on_button18_clicked (GtkWidget *widget, gpointer user_data);

void on_button19_clicked (GtkWidget *widget, gpointer user_data);

void on_treeview1_row_activated (GtkWidget *widget, GtkTreePath *path, GtkTreeViewColumn *column, gpointer user_data);

void on_treeview2_row_activated (GtkWidget *widget, GtkTreePath *path, GtkTreeViewColumn *column, gpointer user_data);

void on_button20_clicked (GtkWidget *widget, gpointer user_data);

void on_button21_clicked (GtkWidget *widget, gpointer user_data);

void on_button22_clicked (GtkWidget *widget, gpointer user_data);

void on_button24_clicked (GtkWidget *widget, gpointer user_data);

void on_button25_clicked (GtkWidget *widget, gpointer user_data);

void on_button26_clicked (GtkWidget *widget, gpointer user_data);

void on_treeview3_row_activated (GtkWidget *widget, GtkTreePath *path, GtkTreeViewColumn *column, gpointer user_data);

void on_button27_clicked (GtkWidget *widget, gpointer user_data);

void on_button28_clicked (GtkWidget *widget, gpointer user_data);

void
on_button_inscription_Adh__rant_clicked
					(GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_Adherant_donne_personnel_clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data);



void
on_button_quitter_Adherant_clicked     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_Adherant_evenement_clicked   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_Adherant_seance_clicked      (GtkWidget       *objet_graphique,
                                        gpointer         user_data);





void
on_button_quitter_inscription_clicked  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);



void
on_button_Deconnexion_Adh__rant_clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data);



void
on_button_adherant_quitter_seance_clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_adherant_retour_seance_clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_adherant_retour_evenement_clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_adherant_quitter_evenement_clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_adherant_quitter_donne_personnel_clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_adherant_retour_donn__e_personnel_clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data);



void
on_button_adh_menu_adh_profil_clicked  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_adherant_seance_modifetsupp_clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_adh_event_supp_clicked       (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_adh_event_modifier_clicked   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_adh_event_ajout_clicked      (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_adh_gestseance_return_clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_adh_gestseance_quitter_clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_adh_gestseance_modifier_clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_adh_gestseance_supp_clicked  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_adh_event_participate_clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_adh_grstevent_retour_clicked (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_adh_grstevent_modif_clicked  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_adh_grstevent_supp_clicked   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_combobox_adh_seance_type_changed    (GtkWidget     *objet_graphique,
                                        gpointer         user_data);

void
on_button_adherant_seance_ajout_clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data);


on_treeview_adherant_evenement_row_activated
                                        (GtkWidget     *objet_graphique,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);



void
on_treeview_adherant_gestevent_row_activated
                                        (GtkWidget     *objet_graphique,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);


on_treeview_adh_gestionseance_row_activated
					(GtkWidget     *objet_graphique,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);



void
on_button_adh_profil_modif_clicked     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_adh_profil_quitter_clicked   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_adh_profil_retour_clicked    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);



void
on_button_kine_rendezvous_clicked    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_kine_disponibilte_supp_clicked
                                      (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_kine_disponibilte_ajout_clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_kine_disponibilite_retour_clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data);
void
on_button_kine_disponibilite_clicked  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_kine_disponibilite_mod_clicked
                                       (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_kine_disponibilite_mod_clicked
                                       (GtkWidget       *objet_graphique,
                                        gpointer         user_data);
void
on_button_liste_rendez_vous_retour_clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data);
void
on_button_mod_disp_kine_retour_clicked  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);
void
on_button_supp_disp_kine_retour_clicked
                                         (GtkWidget       *objet_graphique,
                                        gpointer         user_data);
void
on_button_ajouter_dispo_kine_retour_clicked
                                       (GtkWidget       *objet_graphique,
                                        gpointer         user_data);






void
on_button_kine_dispo_actualiser_clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_kine_disponibilite_actualiser_clicked
                                         (GtkWidget       *objet_graphique,
                                        gpointer         user_data);






void
on_button_kine_menu_retour_clicked     (GtkWidget      *objet_graphique,
                                         gpointer         user_data);



void
on_button_kine_ajouter_disponibilite_clicked
                                        (GtkWidget      *objet_graphique,
                                         gpointer         user_data);

void
on_button_kine_supprimer_disponibilite_clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_kine_actualiser_supprimer_disponibilite_clicked
                                         (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_kine_confirmer_modifier_disponibilite_clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data);


void
on_button_kine_actualiser_modifier_disponibilite_clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data);


void
on_button_kine_modifier_disponibilite_clicked
                                       (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

